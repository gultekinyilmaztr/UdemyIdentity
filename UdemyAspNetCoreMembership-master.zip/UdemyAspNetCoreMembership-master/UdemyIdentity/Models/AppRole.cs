﻿using Microsoft.AspNetCore.Identity;

namespace UdemyIdentity.Models
{
    public class AppRole : IdentityRole
    {
    }
}