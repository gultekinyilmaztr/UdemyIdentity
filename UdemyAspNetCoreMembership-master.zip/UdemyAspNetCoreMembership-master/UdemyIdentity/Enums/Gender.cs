﻿namespace UdemyIdentity.Enums
{
    public enum Gender
    {
        Belirtilmemiş = 0,
        Bay = 1,
        Bayan = 2
    }
}